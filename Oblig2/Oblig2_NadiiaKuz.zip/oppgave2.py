for number in range(9, 102):
    if (number % 2 != 0):
        print(number)

print("----------------------------------------------------------")

number = 9
while number <= 101:
    if (number % 2 != 0):
        print(number)
    number += 1